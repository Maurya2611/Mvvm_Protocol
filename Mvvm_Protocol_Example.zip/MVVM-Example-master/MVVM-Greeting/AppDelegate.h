//
//  AppDelegate.h
//  MVVM-Greeting
//
//  Created by Ivan Magda on 09/09/2016.
//  Copyright © 2016 Ivan Magda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

