import UIKit
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    // MARK: Instance Variables
    var window: UIWindow?
    // MARK: UIApplicationDelegat e
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }
}
