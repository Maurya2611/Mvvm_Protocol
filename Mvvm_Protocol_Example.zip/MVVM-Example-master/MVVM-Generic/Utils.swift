import Foundation
typealias JSONDictionary = [String: AnyObject]
extension String: Error {
}
